"""
Графический интерфейс для сравнения протоколов измерения КИМ (PDF).

Запуск:
    python3 gui.py

Зависимости: pdfplumber, openpyxl, (опционально) pytesseract — для
протоколов, где таблицы это картинки, а не текст.
Tkinter идёт в стандартной поставке Python, отдельно ставить не нужно
(на Linux иногда нужен пакет python3-tk: sudo apt-get install python3-tk).
"""
import sys
import io
import threading
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from compare_cmm import compare, save_xlsx


STATUS_COLORS = {
    "ИЗМЕНИЛСЯ ДОПУСК": "#ffc7ce",
    "отличается измерение": "#ffeb9c",
    "отличается отклонение": "#ffeb9c",
    "только в файле A": "#d9d9d9",
    "только в файле B": "#d9d9d9",
    "общий": None,
}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Сравнение протоколов КИМ")
        self.geometry("1150x650")
        self.file_a = tk.StringVar()
        self.file_b = tk.StringVar()
        self.tol = tk.StringVar(value="0.0005")
        self.rows = []

        self._build_ui()

    # ---------- UI ----------
    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Файл A:").grid(row=0, column=0, sticky="w")
        ttk.Entry(top, textvariable=self.file_a, width=80).grid(row=0, column=1, padx=5)
        ttk.Button(top, text="Обзор…", command=lambda: self._pick(self.file_a)).grid(row=0, column=2)

        ttk.Label(top, text="Файл B:").grid(row=1, column=0, sticky="w", pady=(5, 0))
        ttk.Entry(top, textvariable=self.file_b, width=80).grid(row=1, column=1, padx=5, pady=(5, 0))
        ttk.Button(top, text="Обзор…", command=lambda: self._pick(self.file_b)).grid(row=1, column=2, pady=(5, 0))

        ttk.Label(top, text="Порог отличия, мм:").grid(row=2, column=0, sticky="w", pady=(5, 0))
        ttk.Entry(top, textvariable=self.tol, width=10).grid(row=2, column=1, sticky="w", pady=(5, 0))

        btns = ttk.Frame(top)
        btns.grid(row=2, column=1, sticky="e", pady=(5, 0))
        self.compare_btn = ttk.Button(btns, text="Сравнить", command=self._run_compare)
        self.compare_btn.pack(side="left", padx=5)
        self.export_btn = ttk.Button(btns, text="Сохранить в Excel…", command=self._export, state="disabled")
        self.export_btn.pack(side="left", padx=5)

        # фильтр по статусу
        filt = ttk.Frame(self, padding=(10, 0))
        filt.pack(fill="x")
        ttk.Label(filt, text="Показать:").pack(side="left")
        self.filter_var = tk.StringVar(value="все")
        filter_box = ttk.Combobox(filt, textvariable=self.filter_var, state="readonly", width=28, values=[
            "все", "только отличия", "только изменившие допуск",
            "только в файле A", "только в файле B",
        ])
        filter_box.pack(side="left", padx=5)
        filter_box.bind("<<ComboboxSelected>>", lambda e: self._refresh_table())

        self.summary_label = ttk.Label(self, text="", padding=(10, 5))
        self.summary_label.pack(fill="x")

        # таблица результатов
        cols = ("block", "axis", "measured_a", "measured_b", "delta_measured",
                "dev_a", "dev_b", "status")
        headers = {
            "block": "Блок", "axis": "Ось",
            "measured_a": "Измер. (A)", "measured_b": "Измер. (B)",
            "delta_measured": "Δ Измер.",
            "dev_a": "Откл. (A)", "dev_b": "Откл. (B)",
            "status": "Статус",
        }
        widths = {"block": 300, "axis": 60, "measured_a": 90, "measured_b": 90,
                  "delta_measured": 80, "dev_a": 80, "dev_b": 80, "status": 170}

        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=headers[c])
            self.tree.column(c, width=widths[c], anchor="w")
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        for status, color in STATUS_COLORS.items():
            if color:
                self.tree.tag_configure(status, background=color)

        # лог
        log_frame = ttk.LabelFrame(self, text="Журнал")
        log_frame.pack(fill="x", padx=10, pady=(0, 10))
        self.log_text = tk.Text(log_frame, height=6, state="disabled", wrap="word")
        self.log_text.pack(fill="x")

    # ---------- действия ----------
    def _pick(self, var):
        path = filedialog.askopenfilename(title="Выберите PDF", filetypes=[("PDF файлы", "*.pdf *.PDF")])
        if path:
            var.set(path)

    def _log(self, text):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _run_compare(self):
        a, b = self.file_a.get().strip(), self.file_b.get().strip()
        if not a or not b:
            messagebox.showwarning("Не выбраны файлы", "Укажите оба PDF-файла для сравнения.")
            return
        try:
            tol = float(self.tol.get())
        except ValueError:
            messagebox.showwarning("Некорректный порог", "Порог отличия должен быть числом.")
            return

        self.compare_btn.configure(state="disabled")
        self.export_btn.configure(state="disabled")
        self.summary_label.configure(text="Сравнение выполняется…")
        for i in self.tree.get_children():
            self.tree.delete(i)

        threading.Thread(target=self._compare_worker, args=(a, b, tol), daemon=True).start()

    def _compare_worker(self, a, b, tol):
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            rows = compare(a, b, tol=tol)
            error = None
        except Exception:
            rows = []
            error = traceback.format_exc()
        finally:
            sys.stdout = old_stdout

        log_text = buf.getvalue()
        self.after(0, lambda: self._on_compare_done(rows, log_text, error, a, b))

    def _on_compare_done(self, rows, log_text, error, a, b):
        self.compare_btn.configure(state="normal")
        if log_text:
            self._log(log_text.strip())
        if error:
            self._log(error)
            messagebox.showerror("Ошибка сравнения", "Не удалось выполнить сравнение.\nСмотрите журнал внизу окна.")
            self.summary_label.configure(text="Ошибка сравнения — см. журнал.")
            return

        self.rows = rows
        self.export_btn.configure(state="normal" if rows else "disabled")
        self._refresh_table()

    def _refresh_table(self):
        for i in self.tree.get_children():
            self.tree.delete(i)

        f = self.filter_var.get()
        shown = 0
        for r in self.rows:
            if f == "только отличия" and r["status"] not in (
                    "отличается измерение", "отличается отклонение"):
                continue
            if f == "только изменившие допуск" and r["status"] != "ИЗМЕНИЛСЯ ДОПУСК":
                continue
            if f == "только в файле A" and r["status"] != "только в файле A":
                continue
            if f == "только в файле B" and r["status"] != "только в файле B":
                continue

            self.tree.insert("", "end", values=(
                r["block"], r["axis"],
                r["measured_a"], r["measured_b"], r["delta_measured"],
                r["dev_a"], r["dev_b"], r["status"],
            ), tags=(r["status"],))
            shown += 1

        n_common = sum(1 for r in self.rows if r["status"] not in ("только в файле A", "только в файле B"))
        n_only_a = sum(1 for r in self.rows if r["status"] == "только в файле A")
        n_only_b = sum(1 for r in self.rows if r["status"] == "только в файле B")
        n_tol = sum(1 for r in self.rows if r["status"] == "ИЗМЕНИЛСЯ ДОПУСК")
        n_diff = sum(1 for r in self.rows if r["status"] in ("отличается измерение", "отличается отклонение"))
        self.summary_label.configure(
            text=(f"Всего: {len(self.rows)}   Общих: {n_common}   "
                  f"Только в A: {n_only_a}   Только в B: {n_only_b}   "
                  f"Изменился допуск: {n_tol}   Отличаются значения: {n_diff}   "
                  f"(показано: {shown})")
        )

    def _export(self):
        if not self.rows:
            return
        path = filedialog.asksaveasfilename(
            title="Сохранить результат", defaultextension=".xlsx",
            filetypes=[("Excel файл", "*.xlsx")], initialfile="cmm_compare_result.xlsx")
        if not path:
            return
        try:
            save_xlsx(self.rows, path, self.file_a.get(), self.file_b.get())
            messagebox.showinfo("Готово", f"Результат сохранён:\n{path}")
        except Exception:
            messagebox.showerror("Ошибка сохранения", traceback.format_exc())


if __name__ == "__main__":
    App().mainloop()

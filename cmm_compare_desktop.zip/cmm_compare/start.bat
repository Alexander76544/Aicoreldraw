@echo off
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
setlocal enabledelayedexpansion

echo ============================================
echo   CMM Protocol Compare - starting
echo ============================================
echo.

cd /d "%~dp0"

set "PYTHON_EXE="

REM --- 0) manual override: if python_path.txt exists next to this
REM     script, use the path written inside it (one line, full path
REM     to python.exe). Handy if auto-detection ever picks the wrong
REM     copy or can't find it.
if exist "%~dp0python_path.txt" (
    set /p PYTHON_EXE=<"%~dp0python_path.txt"
    if defined PYTHON_EXE (
        if not exist "!PYTHON_EXE!" (
            echo [!] python_path.txt points to a file that does not exist:
            echo     !PYTHON_EXE!
            echo     Fix or delete python_path.txt and try again.
            echo.
            pause
            exit /b 1
        )
    )
)

REM --- 1) already in PATH? (works if IT admin ever adds it, or on a
REM     normal home PC where this is unnecessary but harmless)
if not defined PYTHON_EXE (
    for /f "delims=" %%P in ('where python 2^>nul') do (
        if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    )
)

REM --- 2) common folder names right next to this script (no admin
REM     rights needed - this is just a plain subfolder you copied
REM     your portable Python into)
if not defined PYTHON_EXE (
    for %%D in (python Python python3 Python3 py python-portable WPy64 winpython) do (
        if exist "%~dp0%%D\python.exe" set "PYTHON_EXE=%~dp0%%D\python.exe"
    )
)

REM --- 3) fallback: search every subfolder of this script's folder
REM     for a file literally named python.exe, use the first match
if not defined PYTHON_EXE (
    echo [i] python.exe not found in the usual spots - searching subfolders...
    set "FOUND_COUNT=0"
    for /f "delims=" %%P in ('dir /s /b "%~dp0python.exe" 2^>nul') do (
        set /a FOUND_COUNT+=1
        if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
    )
    if !FOUND_COUNT! GTR 1 (
        echo [i] Found !FOUND_COUNT! copies of python.exe under this folder,
        echo     using the first one found: !PYTHON_EXE!
        echo     If that is the wrong one, create python_path.txt next to
        echo     start.bat with the full path to the correct python.exe.
    )
)

if not defined PYTHON_EXE (
    echo [!] Could not find python.exe anywhere in PATH or under this folder.
    echo     Make sure your portable Python folder is somewhere inside:
    echo       %~dp0
    echo     Or create a file named python_path.txt next to start.bat
    echo     containing the full path to python.exe on its own line.
    echo.
    pause
    exit /b 1
)

echo [i] Using Python: !PYTHON_EXE!
"!PYTHON_EXE!" --version
if errorlevel 1 (
    echo [!] Found a python.exe but it did not run correctly:
    echo     !PYTHON_EXE!
    echo     It may be corrupted or incompatible. Delete python_path.txt
    echo     if you created one, or point it at a working python.exe.
    echo.
    pause
    exit /b 1
)

echo [i] Checking pip...
"!PYTHON_EXE!" -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [i] pip not available - bootstrapping it via ensurepip...
    "!PYTHON_EXE!" -m ensurepip --upgrade >nul 2>nul
    "!PYTHON_EXE!" -m pip --version >nul 2>nul
    if errorlevel 1 (
        echo [!] Could not get pip working for this Python. If this is a
        echo     minimal/embeddable Python build, it may not support pip
        echo     out of the box. Try a portable "full" Python build instead
        echo     (e.g. WinPython, or the regular python.org installer run
        echo     with "Install for me only" - no admin rights needed for that).
        echo.
        pause
        exit /b 1
    )
)

echo [i] Checking/installing Python dependencies...
"!PYTHON_EXE!" -m pip install --quiet --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo [!] Failed to install dependencies via pip.
    echo     Check your internet connection and try again.
    echo.
    pause
    exit /b 1
)

echo [i] Checking tkinter module...
"!PYTHON_EXE!" -c "import tkinter" 2>nul
if errorlevel 1 (
    echo [!] This Python is missing the tkinter module, so the window
    echo     cannot open. Minimal/embeddable Python builds often lack it.
    echo     Use a "full" portable Python build that includes tkinter
    echo     (regular python.org build, or WinPython).
    echo.
    pause
    exit /b 1
)

echo [i] Checking Tesseract OCR (needed for PDFs where tables are images)...
where tesseract >nul 2>nul
if errorlevel 1 (
    echo [i] Tesseract not found in PATH - that is fine, cmm_parser.py
    echo     looks for a local "tesseract" folder next to these scripts
    echo     automatically (see README.txt).
)

echo.
echo [i] Starting the program...
echo.
"!PYTHON_EXE!" gui.py
set "EXIT_CODE=!errorlevel!"

echo.
if not "!EXIT_CODE!"=="0" (
    echo [!] The program exited with an error code !EXIT_CODE! ^(see text above^).
) else (
    echo [i] The program window was closed normally.
)
echo.
echo Press any key to close this window . . .
pause >nul

endlocal

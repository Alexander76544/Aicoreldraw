"""
Сравнение двух (или более) протоколов измерения КИМ в формате PDF.

Использование:
    python3 compare_cmm.py файл1.pdf файл2.pdf [-o результат.xlsx] [--tol 0.001]

Логика:
  - каждый протокол разбирается на записи (элемент/блок + ось + номинал +
    допуски + измеренное значение + отклонение + "вне допуска");
  - записи сопоставляются по паре (название блока, обозначение оси) —
    по порядку следования, если названия дублируются;
  - для общих записей считается разница измеренных значений и отклонений;
  - отдельно отмечаются элементы, которые есть только в одном из файлов,
    и элементы, у которых изменился статус "в допуске / вне допуска".
"""
import argparse
import sys
from cmm_parser import parse_pdf, records_to_index

try:
    import openpyxl
    from openpyxl.styles import PatternFill, Font
    HAVE_XLSX = True
except ImportError:
    HAVE_XLSX = False


def clean_block_name(name):
    if not name:
        return name
    n = name.strip()
    for junk in ("ММ ", "мм "):
        if n.startswith(junk):
            n = n[len(junk):]
    return n.strip()


def compare(path_a, path_b, tol=0.0005):
    recs_a = parse_pdf(path_a)
    recs_b = parse_pdf(path_b)
    idx_a = records_to_index(recs_a)
    idx_b = records_to_index(recs_b)

    all_keys = list(idx_a.keys()) + [k for k in idx_b.keys() if k not in idx_a]

    rows = []
    for key in all_keys:
        ra = idx_a.get(key)
        rb = idx_b.get(key)
        block = clean_block_name((ra or rb)["block"])
        axis = (ra or rb)["axis"]

        if ra and rb:
            status = "общий"
            d_measured = None
            if ra["measured"] is not None and rb["measured"] is not None:
                d_measured = round(rb["measured"] - ra["measured"], 4)
            d_dev = None
            if ra["dev"] is not None and rb["dev"] is not None:
                d_dev = round(rb["dev"] - ra["dev"], 4)

            oot_a = (ra["out_of_tol"] or 0) > 0
            oot_b = (rb["out_of_tol"] or 0) > 0
            if oot_a != oot_b:
                status = "ИЗМЕНИЛСЯ ДОПУСК"
            elif d_measured is not None and abs(d_measured) > tol:
                status = "отличается измерение"
            elif d_dev is not None and abs(d_dev) > tol:
                status = "отличается отклонение"
        elif ra and not rb:
            status = "только в файле A"
            d_measured = d_dev = None
            oot_a = (ra["out_of_tol"] or 0) > 0
            oot_b = None
        else:
            status = "только в файле B"
            d_measured = d_dev = None
            oot_a = None
            oot_b = (rb["out_of_tol"] or 0) > 0

        rows.append({
            "block": block,
            "axis": axis,
            "nominal_a": ra["nominal"] if ra else None,
            "measured_a": ra["measured"] if ra else None,
            "dev_a": ra["dev"] if ra else None,
            "out_of_tol_a": ra["out_of_tol"] if ra else None,
            "nominal_b": rb["nominal"] if rb else None,
            "measured_b": rb["measured"] if rb else None,
            "dev_b": rb["dev"] if rb else None,
            "out_of_tol_b": rb["out_of_tol"] if rb else None,
            "delta_measured": d_measured,
            "delta_dev": d_dev,
            "status": status,
        })
    return rows


def print_summary(rows, name_a, name_b):
    n_common = sum(1 for r in rows if r["status"] not in ("только в файле A", "только в файле B"))
    n_only_a = sum(1 for r in rows if r["status"] == "только в файле A")
    n_only_b = sum(1 for r in rows if r["status"] == "только в файле B")
    n_changed_tol = sum(1 for r in rows if r["status"] == "ИЗМЕНИЛСЯ ДОПУСК")
    n_diff = sum(1 for r in rows if r["status"] in ("отличается измерение", "отличается отклонение"))

    print(f"\nСравнение: {name_a}  <->  {name_b}")
    print(f"  общих элементов:                 {n_common}")
    print(f"  только в файле A ({name_a}):      {n_only_a}")
    print(f"  только в файле B ({name_b}):      {n_only_b}")
    print(f"  изменился статус допуска:        {n_changed_tol}")
    print(f"  отличаются значения:             {n_diff}")

    if n_changed_tol:
        print("\n--- Элементы, изменившие статус допуска ---")
        for r in rows:
            if r["status"] == "ИЗМЕНИЛСЯ ДОПУСК":
                print(f"  [{r['block']}] {r['axis']}: "
                      f"A измер.={r['measured_a']} вне_доп={r['out_of_tol_a']}  "
                      f"B измер.={r['measured_b']} вне_доп={r['out_of_tol_b']}")


def save_xlsx(rows, out_path, name_a, name_b):
    if not HAVE_XLSX:
        print("openpyxl не установлен — сохранение в Excel пропущено (используйте --csv).")
        return
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Сравнение"

    headers = ["Блок", "Ось", f"Номинал ({name_a})",
               f"Измер. ({name_a})", f"Откл. ({name_a})", f"Вне доп. ({name_a})",
               f"Измер. ({name_b})", f"Откл. ({name_b})", f"Вне доп. ({name_b})",
               "Δ Измер.", "Δ Откл.", "Статус"]
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)

    red = PatternFill("solid", fgColor="FFC7CE")
    yellow = PatternFill("solid", fgColor="FFEB9C")
    grey = PatternFill("solid", fgColor="D9D9D9")

    for r in rows:
        ws.append([
            r["block"], r["axis"],
            r["nominal_a"], r["measured_a"], r["dev_a"], r["out_of_tol_a"],
            r["measured_b"], r["dev_b"], r["out_of_tol_b"],
            r["delta_measured"], r["delta_dev"], r["status"],
        ])
        row_cells = ws[ws.max_row]
        if r["status"] == "ИЗМЕНИЛСЯ ДОПУСК":
            fill = red
        elif r["status"] in ("отличается измерение", "отличается отклонение"):
            fill = yellow
        elif r["status"] in ("только в файле A", "только в файле B"):
            fill = grey
        else:
            fill = None
        if fill:
            for c in row_cells:
                c.fill = fill

    for col_cells in ws.columns:
        length = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
        ws.column_dimensions[col_cells[0].column_letter].width = min(max(length + 2, 10), 45)

    wb.save(out_path)
    print(f"\nРезультат сохранён: {out_path}")


def main():
    ap = argparse.ArgumentParser(description="Сравнение протоколов измерения КИМ (PDF).")
    ap.add_argument("file_a", help="первый PDF-протокол")
    ap.add_argument("file_b", help="второй PDF-протокол")
    ap.add_argument("-o", "--output", default="cmm_compare_result.xlsx", help="файл результата (.xlsx)")
    ap.add_argument("--tol", type=float, default=0.0005, help="порог отличия значений, мм")
    args = ap.parse_args()

    rows = compare(args.file_a, args.file_b, tol=args.tol)
    print_summary(rows, args.file_a, args.file_b)
    save_xlsx(rows, args.output, args.file_a, args.file_b)


if __name__ == "__main__":
    main()

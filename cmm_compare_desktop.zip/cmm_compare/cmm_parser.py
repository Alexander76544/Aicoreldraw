"""
Парсер протоколов измерения КИМ (координатно-измерительной машины) из PDF.
Извлекает для каждого измеряемого элемента: номинал, допуски, измеренное
значение, отклонение и статус "вне допуска".

Некоторые протоколы КИМ экспортируются так, что строки таблицы на самом деле
растровые картинки (например, чтобы сохранить цветную подсветку "вне
допуска"), а не настоящий текст. Для таких страниц модуль автоматически
переключается на распознавание текста (OCR) через Tesseract.
"""
import os
import re
import shutil
import sys
import pdfplumber
from collections import defaultdict

try:
    import pytesseract
    HAVE_OCR = True
except ImportError:
    HAVE_OCR = False

MIN_NATIVE_WORDS = 15   # если слов меньше — страница считается "картинкой"
OCR_RESOLUTION = 300    # dpi для рендера страницы перед OCR
OCR_LANG_PRIMARY = "rus+eng"
OCR_LANG_FALLBACK = "eng"

_ocr_warned = set()
_tesseract_located = False


def _script_dir():
    # папка, где лежит сам скрипт/exe (работает и из PyInstaller-сборки)
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _candidate_tesseract_paths():
    base = _script_dir()
    names = ("tesseract.exe", "tesseract")
    subfolders = (
        "tesseract",
        os.path.join("tesseract", "bin"),
        os.path.join("tesseract-ocr"),
    )
    candidates = []
    for sub in subfolders:
        for name in names:
            candidates.append(os.path.join(base, sub, name))
    # tesseract.exe прямо рядом со скриптом
    for name in names:
        candidates.append(os.path.join(base, name))
    # стандартные пути установки на Windows
    for env_var in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        root = os.environ.get(env_var)
        if root:
            candidates.append(os.path.join(root, "Tesseract-OCR", "tesseract.exe"))
    # переменная окружения, если пользователь её задал вручную
    env_path = os.environ.get("TESSERACT_PATH")
    if env_path:
        candidates.insert(0, env_path)
    return candidates


def _search_tesseract_recursive(max_depth=3):
    """Ищет tesseract.exe в подпапках рядом со скриптом (на случай нестандартной вложенности)."""
    base = _script_dir()
    base_depth = base.rstrip(os.sep).count(os.sep)
    for root, dirs, files in os.walk(base):
        depth = root.rstrip(os.sep).count(os.sep) - base_depth
        if depth >= max_depth:
            dirs[:] = []
            continue
        for fname in files:
            if fname.lower() in ("tesseract.exe", "tesseract"):
                return os.path.join(root, fname)
    return None


def _win_short_path(path):
    """
    Возвращает короткое имя пути (формат 8.3, только ASCII), если это
    возможно. Нужно потому, что tesseract.exe (старая C/C++ программа)
    может неправильно прочитать переменную окружения с кириллицей в
    пути (например, "Ложкин", "ЦТРД") из-за устаревшей однобайтовой
    кодировки, даже если сам файл на месте. Короткое имя всегда чистая
    латиница/цифры и не подвержено этой проблеме.
    Если получить короткое имя не удалось (не Windows, диск не
    поддерживает 8.3-имена и т.п.) — возвращает исходный путь как есть.
    """
    if os.name != "nt":
        return path
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(260)
        res = ctypes.windll.kernel32.GetShortPathNameW(path, buf, 260)
        if res:
            return buf.value
    except Exception:
        pass
    return path


def locate_tesseract():
    """
    Находит исполняемый файл tesseract и настраивает pytesseract на его
    использование. Также настраивает TESSDATA_PREFIX, если рядом найдена
    папка tessdata (нужна для языковых пакетов, напр. rus.traineddata).
    Возвращает найденный путь или None.
    """
    global _tesseract_located
    if not HAVE_OCR:
        return None

    # 1) уже есть в PATH
    found = shutil.which("tesseract")

    # 2) типичные места рядом со скриптом / стандартные установки
    if not found:
        for path in _candidate_tesseract_paths():
            if os.path.isfile(path):
                found = path
                break

    # 3) поиск по подпапкам рядом со скриптом (на случай другой структуры)
    if not found:
        found = _search_tesseract_recursive()

    if found:
        pytesseract.pytesseract.tesseract_cmd = _win_short_path(found)
        # если рядом есть tessdata — укажем явно, иначе rus.traineddata может не найтись
        tess_dir = os.path.dirname(found)
        tessdata_dir = os.path.join(tess_dir, "tessdata")
        if os.path.isdir(tessdata_dir):
            os.environ["TESSDATA_PREFIX"] = _win_short_path(tess_dir)
        if not _tesseract_located:
            print(f"[i] Tesseract найден: {found}")
            _tesseract_located = True
        return found

    return None


# ищем один раз при импорте модуля
_TESSERACT_PATH = locate_tesseract()


_dll_error_shown = False


def _friendly_tesseract_error(exc):
    """Превращает типовые ошибки запуска tesseract.exe в понятное сообщение."""
    global _dll_error_shown
    msg = str(exc)
    # 0xC0000135 (3221225775) = STATUS_DLL_NOT_FOUND — рядом с tesseract.exe
    # не хватает одной из библиотек, от которых он зависит
    if "3221225775" in msg or "0xC0000135" in msg.upper():
        if not _dll_error_shown:
            print(
                "[!] tesseract.exe найден, но не запускается — Windows не может "
                "найти одну из библиотек (.dll), от которых он зависит "
                "(код ошибки 0xC0000135 / 3221225775).\n"
                "    Обычно это значит, что рядом с tesseract.exe скопированы "
                "не все файлы из оригинальной папки Tesseract-OCR.\n"
                "    Проверьте: откройте папку tesseract и дважды кликните "
                "по tesseract.exe напрямую — Windows покажет всплывающее "
                "окно с точным названием недостающей .dll. Скопируйте "
                "этот файл (и все остальные .dll) из исходной установки "
                "Tesseract-OCR в папку tesseract рядом со скриптами."
            )
            _dll_error_shown = True
        return True
    return False


def _tessdata_config():
    """
    Явный аргумент --tessdata-dir для командной строки tesseract — как
    подстраховка на случай, если TESSDATA_PREFIX через переменную
    окружения почему-то не сработает (см. _win_short_path выше).
    """
    tessdata_dir = os.environ.get("TESSDATA_PREFIX")
    if tessdata_dir and os.path.isdir(os.path.join(tessdata_dir, "tessdata")):
        path = os.path.join(tessdata_dir, "tessdata")
        return f'--tessdata-dir "{path}"'
    return ""


def _extract_words_ocr(page, lang):
    img = page.to_image(resolution=OCR_RESOLUTION).original
    scale = 72.0 / OCR_RESOLUTION  # пиксели -> точки PDF (та же система координат, что и у pdfplumber)
    try:
        data = pytesseract.image_to_data(
            img, lang=lang, config=_tessdata_config(), output_type=pytesseract.Output.DICT
        )
    except Exception as e:
        if _friendly_tesseract_error(e):
            return []
        raise
    words = []
    n = len(data["text"])
    for i in range(n):
        text = data["text"][i].strip()
        if not text:
            continue
        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError):
            conf = -1
        if conf < 0:
            continue
        x0 = data["left"][i] * scale
        top = data["top"][i] * scale
        words.append({"text": text, "x0": x0, "top": top})
    return words


def extract_words_any(page):
    """
    Возвращает (список слов, использовался_ли_OCR).
    Слово — dict с ключами text/x0/top (как у pdfplumber.page.extract_words()).
    """
    native = page.extract_words()
    if len(native) >= MIN_NATIVE_WORDS:
        return native, False

    if not HAVE_OCR:
        return native, False

    if not pytesseract.pytesseract.tesseract_cmd or pytesseract.pytesseract.tesseract_cmd == "tesseract":
        # tesseract_cmd по умолчанию — просто "tesseract", т.е. locate_tesseract() ничего не нашёл
        if "no_tesseract" not in _ocr_warned:
            print("[!] Tesseract OCR не найден (ни в PATH, ни в папке рядом со скриптом, "
                  "ни в стандартных папках установки). Страницы, где таблица — это "
                  "картинка, не будут распознаны.\n"
                  "    Положите папку с tesseract.exe рядом со скриптами (например, "
                  "в подпапку 'tesseract'), либо установите Tesseract с "
                  "https://github.com/UB-Mannheim/tesseract/wiki, либо задайте "
                  "переменную окружения TESSERACT_PATH с полным путём к tesseract.exe.")
            _ocr_warned.add("no_tesseract")
        return native, False

    try:
        return _extract_words_ocr(page, OCR_LANG_PRIMARY), True
    except pytesseract.TesseractNotFoundError:
        if "not_found_runtime" not in _ocr_warned:
            print(f"[!] Не удалось запустить Tesseract по пути "
                  f"'{pytesseract.pytesseract.tesseract_cmd}'. Проверьте, что файл существует "
                  f"и не заблокирован антивирусом.")
            _ocr_warned.add("not_found_runtime")
        return native, False
    except pytesseract.TesseractError:
        if OCR_LANG_PRIMARY not in _ocr_warned:
            print(f"[!] Языковой пакет Tesseract '{OCR_LANG_PRIMARY}' не найден — "
                  f"использую '{OCR_LANG_FALLBACK}' (для корректного распознавания "
                  f"кириллицы нужен файл rus.traineddata в папке tessdata рядом с "
                  f"tesseract.exe).")
            _ocr_warned.add(OCR_LANG_PRIMARY)
        try:
            return _extract_words_ocr(page, OCR_LANG_FALLBACK), True
        except pytesseract.TesseractError:
            if "eng_fail" not in _ocr_warned:
                print("[!] OCR не смог распознать страницу даже с базовым пакетом 'eng'.")
                _ocr_warned.add("eng_fail")
            return native, False

# Колонки, которые встречаются в шапках таблиц протокола (варианты написания)
HEADER_TOKENS = {"ОСЬ", "ЭЛЕМЕНТ"}
COL_TOKENS = ["НОМИНАЛ", "+", "В.О.", "-Н.О.", "ИЗМЕР.", "ОТКЛ", "ВНЕДОП", "ВНЕ", "ДОП", "ПРИРАЩ"]

ROW_TOP_TOL = 2.5      # px — слова с разницей top меньше этого считаем одной строкой
COL_MATCH_TOL = 40      # px — макс. расстояние от числа до центра колонки


def _cluster_rows(words):
    """Группирует слова в строки по координате top."""
    words = sorted(words, key=lambda w: (w["top"], w["x0"]))
    rows = []
    cur = []
    cur_top = None
    for w in words:
        if cur_top is None or abs(w["top"] - cur_top) <= ROW_TOP_TOL:
            cur.append(w)
            cur_top = w["top"] if cur_top is None else cur_top
        else:
            rows.append(cur)
            cur = [w]
            cur_top = w["top"]
    if cur:
        rows.append(cur)
    for r in rows:
        r.sort(key=lambda w: w["x0"])
    return rows


def _is_header_row(row_texts):
    up = [t.upper() for t in row_texts]
    return any(t in HEADER_TOKENS for t in up) and "НОМИНАЛ" in up and any(
        t.startswith("ИЗМЕР") for t in up
    )


def _build_columns(row):
    """Строит карту колонок {имя_колонки: x_центр} из строки-шапки."""
    cols = {}
    tokens = [(w["text"], w["x0"]) for w in row]
    i = 0
    while i < len(tokens):
        text, x0 = tokens[i]
        up = text.upper()
        if up in ("ОСЬ", "ЭЛЕМЕНТ"):
            cols["axis"] = x0
        elif up == "НОМИНАЛ":
            cols["nominal"] = x0
        elif up == "+":
            # "+" и "В.О." идут парой
            if i + 1 < len(tokens) and tokens[i + 1][0].upper() == "В.О.":
                x1 = tokens[i + 1][1]
                cols["plus_tol"] = (x0 + x1) / 2
                i += 1
        elif up == "-Н.О.":
            cols["minus_tol"] = x0
        elif up.startswith("ИЗМЕР"):
            cols["measured"] = x0
        elif up == "ОТКЛ":
            cols["dev"] = x0
        elif up in ("ВНЕДОП",):
            cols["out_of_tol"] = x0
        elif up == "ВНЕ":
            if i + 1 < len(tokens) and tokens[i + 1][0].upper() == "ДОП":
                x1 = tokens[i + 1][1]
                cols["out_of_tol"] = (x0 + x1) / 2
                i += 1
        elif up == "ПРИРАЩ":
            cols["increment"] = x0
        i += 1
    return cols


_NUM_RE = re.compile(r"^-?\d+[.,]\d+$")


def _to_float(s):
    try:
        return float(s.replace(",", "."))
    except ValueError:
        return None


def parse_pdf(path):
    """
    Возвращает список записей:
    {block, axis, nominal, plus_tol, minus_tol, measured, dev, out_of_tol,
     increment, page}
    """
    records = []
    ocr_pages = 0
    with pdfplumber.open(path) as pdf:
        for page_idx, page in enumerate(pdf.pages, start=1):
            words, used_ocr = extract_words_any(page)
            if used_ocr:
                ocr_pages += 1
            if not words:
                continue
            rows = _cluster_rows(words)

            cols = None
            block_title = None
            prev_row_text = None

            for row in rows:
                texts = [w["text"] for w in row]
                line = " ".join(texts)

                if _is_header_row(texts):
                    cols = _build_columns(row)
                    # заголовок блока — предыдущая непустая строка (не шапка колонок)
                    if prev_row_text:
                        block_title = prev_row_text
                    continue

                if cols is None:
                    prev_row_text = line
                    continue

                # строка данных: первое слово — подпись оси/элемента,
                # остальное — числа, которые нужно раскидать по колонкам
                axis_label = texts[0]
                value_words = row[1:]
                numeric_words = [w for w in value_words if _NUM_RE.match(w["text"])]
                if not numeric_words:
                    # это не строка с данными (например, разрыв блока) —
                    # тогда это потенциальный новый заголовок блока
                    prev_row_text = line
                    cols = None
                    continue

                rec = {
                    "block": block_title or "?",
                    "axis": axis_label,
                    "nominal": None,
                    "plus_tol": None,
                    "minus_tol": None,
                    "measured": None,
                    "dev": None,
                    "out_of_tol": None,
                    "increment": None,
                    "page": page_idx,
                }
                for w in numeric_words:
                    val = _to_float(w["text"])
                    # найти ближайшую колонку по x0
                    best_col, best_dist = None, 1e9
                    for cname, cx in cols.items():
                        if cname == "axis":
                            continue
                        d = abs(w["x0"] - cx)
                        if d < best_dist:
                            best_dist, best_col = d, cname
                    if best_col and best_dist <= COL_MATCH_TOL:
                        rec[best_col] = val
                records.append(rec)
                prev_row_text = line

    if ocr_pages:
        print(f"[i] {path}: {ocr_pages} стр. распознано через OCR "
              f"(таблица в PDF была картинкой, не текстом).")
        if len(records) < 5:
            print(f"[!] {path}: после OCR извлечено подозрительно мало записей "
                  f"({len(records)}). Вероятная причина — в системе не установлен "
                  f"русский языковой пакет Tesseract. Установите его и повторите:\n"
                  f"    Linux:   sudo apt-get install tesseract-ocr-rus\n"
                  f"    Windows: при установке Tesseract отметьте пакет 'Russian'\n"
                  f"             (или скачайте rus.traineddata в папку tessdata)")
    return records


def records_to_index(records):
    """
    Индексирует записи по ключу (блок, ось), объединяя дубли номером
    повторения, если такая пара уже встречалась (напр. несколько строк 'X').
    """
    index = {}
    counters = defaultdict(int)
    for r in records:
        key_base = (r["block"].strip(), r["axis"].strip())
        counters[key_base] += 1
        key = key_base if counters[key_base] == 1 else key_base + (counters[key_base],)
        index[key] = r
    return index
